public class mainController {
   public static void main(String[] args){
       menu m = new menu();
   }
}
